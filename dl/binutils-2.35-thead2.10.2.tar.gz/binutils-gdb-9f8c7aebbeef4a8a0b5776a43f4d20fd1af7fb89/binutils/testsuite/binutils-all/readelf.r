
Relocation section '.rel.*' at offset 0x.* contains . entr(y|ies):
 Offset     Info    Type            Sym.Value  Sym. Name.*
# NDS32 targets puts R_NDS32_RELAX_ENT here
#...
00000004  [0-9A-Fa-f]+ *R_.*00000000   external_symbol.*
